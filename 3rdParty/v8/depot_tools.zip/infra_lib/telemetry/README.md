# Chrome Infra Telemetry

TODO: This a placeholder to establish a folder to build the telemetry lib, this
will be filled out in follow up CLs